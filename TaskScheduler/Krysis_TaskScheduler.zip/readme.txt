-- INSTALLATION --
1. Extract Krysis_TaskScheduler.dll in to the "Addons" folder of MacrosEngine main folder. (C:\Program Files (x86)\MacrosEngine\Addons)

------------------

Documentation: https://docs.krys.is/macrosengine-plugins/task-scheduler

Task Scheduler MacrosEngine Plugin was created by Krysis - https://krys.is/
