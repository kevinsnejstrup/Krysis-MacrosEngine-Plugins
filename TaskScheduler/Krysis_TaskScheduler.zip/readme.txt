-- INSTALLATION --
1. Extract Krysis_TaskScheduler.dll in to the "Addons" folder of MacrosEngine main folder. (C:\Program Files (x86)\MacrosEngine\Addons)

------------------

Documentation: https://docs.krys.is/macrosengine-plugins/task-scheduler

Donate and get notifications on updates, and early access to other software & plugins for MacrosEngine!
Donate here: https://www.buymeacoffee.com/Krysis

Task Scheduler MacrosEngine Plugin was created by Krysis - https://krys.is/
