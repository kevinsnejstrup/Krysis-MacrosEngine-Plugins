-- INSTALLATION --
1. Extract all files inside of the "required" folder in to MacrosEngine main folder. (C:\Program Files (x86)\MacrosEngine)
	- It was not possible to pack these files in to the main file.

2. Extract Krysis_AutoIt.dll in to the "Addons" folder of MacrosEngine main folder. (C:\Program Files (x86)\MacrosEngine\Addons)

3. When you compile your bot, you will need to extract all files within "required" to your compiled bots folder.
	- This is unfortunately not done automatically at the moment.

------------------

Documentation: https://docs.krys.is/macrosengine-plugins/autoit

Donate and get notifications on updates, and early access to other software & plugins for MacrosEngine!
Donate here: https://www.buymeacoffee.com/Krysis

AutoIt MacrosEngine Plugin was created by Krysis - https://krys.is/
