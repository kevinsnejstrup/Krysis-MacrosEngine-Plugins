-- INSTALLATION --

1. Extract Krysis_MySQL.dll in to the "Addons" folder of MacrosEngine main folder. (C:\Program Files (x86)\MacrosEngine\Addons)

------------------

Documentation: https://docs.krys.is/macrosengine-plugins/mysql

MySQL MacrosEngine Plugin was created by Krysis - https://krys.is/
